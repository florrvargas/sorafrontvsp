// const { transporter } = require("../transporter/transporter");


// async function mailUsuarioCreado(correo, asunto, texto) {
   
//     try {
//         await transporter.sendMail({
//             from: '"Sora" <findmeahome2022@gmail.com>',
//             to: `${correo}`,
//             subject: `${asunto}`,
//             html: `${texto}`
//         })
//     } catch (error) {
//         console.log(error);
//     }
// }

// module.exports = {
//     mailUsuarioCreado
// }